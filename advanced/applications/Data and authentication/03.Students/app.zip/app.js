function attachEvents() {
    document.getElementById('form').addEventListener('submit', onSubmit)
    window.addEventListener('load', onLoad)
    const url = 'http://localhost:3030/jsonstore/collections/students';

    async function onSubmit(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const { firstName, lastName, facultyNumber, grade } = Object.fromEntries(formData.entries());
        if (!firstName || !lastName || !facultyNumber || !grade) {
            return
        }

        const options = {
            method: 'post',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ firstName, lastName, facultyNumber, grade })
        }

        const response = await fetch(url, options)
        onLoad();
    }

    async function onLoad() {
        const response = await fetch(url)
        const data = await response.json();
        const tBody = document.querySelector('tbody');
        tBody.textContent = '';
        
        Object.values(data).forEach(student => {
            const row = document.createElement('tr');
            tBody.appendChild(createAndAppendStudents(student, row))
        })
    }

    function createAndAppendStudents(obj, parent) {
        const firstName = document.createElement('td');
        const lastName = document.createElement('td');
        const facultyNumber = document.createElement('td');
        const grade = document.createElement('td');
        firstName.textContent = obj.firstName;
        lastName.textContent = obj.lastName;
        facultyNumber.textContent = obj.facultyNumber;
        grade.textContent = obj.grade;
        parent.appendChild(firstName);
        parent.appendChild(lastName);
        parent.appendChild(facultyNumber);
        parent.appendChild(grade);

        return parent;
    }

}

attachEvents()